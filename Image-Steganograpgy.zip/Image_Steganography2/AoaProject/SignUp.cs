﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace AoaProject
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            string source = "Data Source=HAIER-PC;Initial Catalog=AoaProject;Integrated Security=True";
            SqlConnection con = new SqlConnection(source);
            con.Open();
            string sqlSelectQuery = "select * from MyTable where Email='" + txtemail.Text + "'";
            SqlCommand comd = new SqlCommand(sqlSelectQuery, con);
            SqlDataReader dr = comd.ExecuteReader();
            if (dr.Read())
            {
                MessageBox.Show("User already exits");
                empty();
            }
            else if (txtpass.Text != txtconfrmpass.Text)
            {
                MessageBox.Show("password not match");
               
            }
            else
            {
                string setting = "Data Source=HAIER-PC;Initial Catalog=AoaProject;Integrated Security=True";
                SqlConnection connection = new SqlConnection(setting);
                connection.Open();
                string query = "insert into MyTable(Username,Email,Password)values('" + txtusername.Text + "','" + txtemail.Text + "','" + txtpass.Text + "')";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                MessageBox.Show("Sign Up Successfully");
                empty();
                connection.Close();
                

            }

        }
        private void empty()
        {
            txtconfrmpass.Text = " ";
            txtemail.Text = " ";
            txtpass.Text = " ";
            txtusername.Text = " ";
        }
        private void linkforlogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login lg = new Login();
            lg.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtusername_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtusername.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtusername, "Enter username");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtusername, null);
            }
        }

        private void txtusername_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtusername, null);
        }

        private void txtemail_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtemail.Text))
            {
                e.Cancel = true;
                errorProvider2.SetError(txtemail, "Enter email");
            }
            else
            {
                e.Cancel = false;
                errorProvider2.SetError(txtemail, null);
            }
        }

        private void txtemail_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtemail, null);
        }

        private void txtpass_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtpass.Text))
            {
                e.Cancel = true;
                errorProvider3.SetError(txtpass, "Enter password");
            }
            else
            {
                e.Cancel = false;
                errorProvider3.SetError(txtpass, null);
            }
        }

        private void txtpass_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtpass, null);
        }

        private void txtconfrmpass_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtconfrmpass.Text))
            {
                e.Cancel = true;
                errorProvider4.SetError(txtconfrmpass, "Enter confirm password");
            }
            else
            {
                e.Cancel = false;
                errorProvider4.SetError(txtconfrmpass, null);
            }
        }

        private void txtconfrmpass_Validated(object sender, EventArgs e)
        {
            errorProvider4.SetError(txtconfrmpass, null);
        }
    }
}
