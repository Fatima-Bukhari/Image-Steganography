﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Image_Steganography
{
    public partial class Choice : Form
    {
        public static string SetValueForId;
        public static string decrypted_path;
        public Choice(string str)
        {
            InitializeComponent();
             SetValueForId= str;
        }

        private void Encode_btn1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1(SetValueForId);
            frm.Show();
            this.Hide();
        }

        private void Choice_Load(object sender, EventArgs e)
        {

        }

        private void Decode_btn1_Click(object sender, EventArgs e)
        {
            Decode frm = new Decode(SetValueForId);
            frm.Show();
            this.Hide();
        }
    }
}
