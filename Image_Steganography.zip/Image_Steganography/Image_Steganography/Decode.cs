﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;
namespace Image_Steganography
{
    public partial class Decode : Form
    {
        private Form1 mainForm = null;
        public static string SetValueForId;
        public Decode(string str)
        {
            InitializeComponent();
            TransectionId_txt.Text = str;
           
        }
        
        public Decode(Form callingForm)
        {
            mainForm = callingForm as Form1;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string setting = "data source=desktop-2osj5nq;initial catalog=aoa_database;integrated security=true";
            string query = "SELECT * from Table_7" + " WHERE Security_Key = '" + Key_txt.Text + "'";
            SqlConnection connection = new SqlConnection(setting);
            SqlDataAdapter sd = new SqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                MessageBox.Show("*** Congratulations!! you Entered right key!!");
                string query2 = "select imgPath from Table_7 where imgpath='" + decrypted_imgpath_txt.Text + "'";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr;
                mainForm = new Form1();
                string path = mainForm.DecryptedImg_path;
                try
                {
                    dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                       // listBox1.Items.Add(dr["imgPath"].ToString());
                        decrypted_imgpath_txt.Text = dr["imgPath"].ToString();


                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }                            
              }
            else
            {
                MessageBox.Show("**Wrong Key ");
            }
            connection.Close();
           
        }
        private void TransectionId_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Decode_Load(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void save_btn_Click(object sender, EventArgs e)
        {
          /*  string setting = "data source=desktop-2osj5nq;initial catalog=aoa_database;integrated security=true";
            string query = "SELECT * from Table_7" + " WHERE imgpath = '" + decrypted_imgpath_txt.Text + "'";
            SqlConnection connection = new SqlConnection(setting);
            connection.Open();
            SqlDataAdapter sd = new SqlDataAdapter(query, connection);
            DataSet ds = new DataSet();
            sd.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)

            {

                MemoryStream ms = new MemoryStream((byte[])ds.Tables[0].Rows[0]["imgpath"]);

                decrypted_img.Image = new Bitmap(ms);


            }
            connection.Close();*/
                  Bitmap img = new Bitmap(decrypted_imgpath_txt.Text);
                  string message = "";
                 for (int i = 0; i < img.Width; i++)
                  {
                      for (int j = 0; j < img.Height; j++)
                      {
                          Color pixel = img.GetPixel(i, j);
                          if (i < 1 && j < decrypted_imgpath_txt.TextLength)
                          {

                              int value = pixel.B;
                              char c = Convert.ToChar(value);
                              string letter = System.Text.Encoding.ASCII.GetString(new byte[] { Convert.ToByte(c) });
                              message = message + letter;

                          }
                      }
                  }
                  decryptedmsg_txt.Text = message;
                  
            }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
