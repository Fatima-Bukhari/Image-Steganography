﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
namespace Image_Steganography
{
    public partial class Form1 : Form
    {
        public static string SetValueForId;
        private string var1;
        

        public Form1() {
        }
        public Form1(string SetValueForId)
        {
            InitializeComponent();
            TransectionId_txt.Text = SetValueForId;
             Fillcombobox();
        }
       
        void Fillcombobox()
        {
            string setting = "Data Source=DESKTOP-2OSJ5NQ;Initial Catalog=AoA_database;Integrated Security=True";
            SqlConnection connection = new SqlConnection(setting);
            string query = "Select * FROM Table_7";
            SqlCommand cmd = new SqlCommand(query,connection);
            SqlDataReader sdr;
            try
            {
                connection.Open();
                sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    string id = sdr.GetValue(2).ToString();
                    Userid_combobox.Items.Add(id);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image Files (*.png,*.jpg) | *.png; *.jpg";
            openDialog.InitialDirectory = @"D:\Semester 5";

            if (openDialog.ShowDialog()==DialogResult.OK)
            {
                textBox1.Text = openDialog.FileName.ToString();
                pictureBox1.ImageLocation = textBox1.Text;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(textBox1.Text);
            for(int i=0;i<img.Width;i++)
            {
                for(int j=0;j<img.Height;j++)
                {
                    Color pixel = img.GetPixel(i, j);
                    if(i<1 && j<textBox2.TextLength)
                    {
                        Console.WriteLine("R = [ " + i + "][ " + j + "]= " + pixel.R);
                        Console.WriteLine("G = [ " + i + "][ " + j + "]= " + pixel.G);
                        Console.WriteLine("B = [ " + i + "][ " + j + "]= " + pixel.B);

                        char letter = Convert.ToChar(textBox2.Text.Substring(j, 1));
                        int value = Convert.ToInt32(letter);
                        Console.WriteLine("Letter : " + letter + " Value : " + value);

                        img.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, pixel.B, value));
                    }
                }
            }

            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Image Files (*.png,*.jpg) | *.png; *.jpg";
            saveFile.InitialDirectory = @"D:\Semester 5";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = saveFile.FileName.ToString();
                pictureBox1.ImageLocation = textBox1.Text;
                img.Save(textBox1.Text);
            }
           
                  }
        private string decryptedImg_path;

        public string DecryptedImg_path
        {
            get
            {
                return decryptedImg_path;
            }

            set
            {
                decryptedImg_path = textBox1.Text;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /* List<string> idList = new List<string>();
             string setting = "Data Source=DESKTOP-2OSJ5NQ;Initial Catalog=AoA_database;Integrated Security=True";
             SqlConnection connection = new SqlConnection(setting);
             connection.Open();
             string query = "select Id from Table_7 where Name='" + store + "'";
             SqlCommand cmd1 = new SqlCommand(query, connection);
             cmd1.Connection = connection;
             SqlDataReader reader = cmd1.ExecuteReader();
             while (reader.Read())
             {
                 idList.Add(reader.GetValue(0).ToString());
             }
             TransectionId_txt.Text = displayMembers(idList);

             reader.Close();
             cmd1.Dispose();
             connection.Close();*/
           // TransectionId_txt.Text = store;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void TransectionId_txt_TextChanged(object sender, EventArgs e)
        {
           
        }
        public string displayMembers(List<String> idList)
        {
            return string.Join(", ", idList.ToArray());
        }

        private void Key_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            string setting = "Data Source=DESKTOP-2OSJ5NQ;Initial Catalog=AoA_database;Integrated Security=True";
            SqlConnection connection = new SqlConnection(setting);
            byte[] im = null;
            FileStream fs = new FileStream(textBox1.Text, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            im = br.ReadBytes((int)fs.Length);
            string query1 = "update Table_7 set imgpath='" + this.textBox1.Text + "' where Id='" + this.Userid_combobox.SelectedItem + "';";
            connection.Open();
            SqlCommand cmd = new SqlCommand(query1, connection);
            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("****Encrypted Picture has been sent to respective ID ");
            }
            else
            {
                MessageBox.Show("******Encrypted Picture has not been sent to respective ID");
            }
            string query2 = "update Table_7 set Message='" + this.textBox2.Text + "' where Id='" + this.Userid_combobox.SelectedItem + "'";

            SqlCommand cmd1 = new SqlCommand(query2, connection);

            if (cmd1.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("**Message has been Sent to respective user");
            }
            else
            {
                MessageBox.Show("**Message has been Sent to respective user");
            }


            string query3 = "UPDATE Table_7 set Security_Key='" + this.Key_txt.Text + "' WHERE Id='" + this.Userid_combobox.SelectedItem + "'";

            SqlCommand cmd3 = new SqlCommand(query3, connection);

            if (cmd3.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("**Security Key has been Sent to respective user");
            }
            else
            {
                MessageBox.Show("**Security Key has been Sent to respective user");
            }

            connection.Close();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
