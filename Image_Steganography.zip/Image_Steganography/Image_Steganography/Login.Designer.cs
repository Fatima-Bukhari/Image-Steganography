﻿namespace Image_Steganography
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lgnName_lbl = new System.Windows.Forms.Label();
            this.lgnName_txt = new System.Windows.Forms.TextBox();
            this.lgn_btn = new System.Windows.Forms.Button();
            this.lgnPassword_lbl = new System.Windows.Forms.Label();
            this.lgnPassword_txt = new System.Windows.Forms.TextBox();
            this.link_lbl = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Decode_btn1 = new System.Windows.Forms.Button();
            this.Encode_btn1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lgnName_lbl
            // 
            this.lgnName_lbl.AutoSize = true;
            this.lgnName_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgnName_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lgnName_lbl.Location = new System.Drawing.Point(236, 141);
            this.lgnName_lbl.Name = "lgnName_lbl";
            this.lgnName_lbl.Size = new System.Drawing.Size(63, 24);
            this.lgnName_lbl.TabIndex = 0;
            this.lgnName_lbl.Text = "Name";
            // 
            // lgnName_txt
            // 
            this.lgnName_txt.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgnName_txt.Location = new System.Drawing.Point(349, 141);
            this.lgnName_txt.Name = "lgnName_txt";
            this.lgnName_txt.Size = new System.Drawing.Size(171, 32);
            this.lgnName_txt.TabIndex = 1;
            // 
            // lgn_btn
            // 
            this.lgn_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgn_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lgn_btn.Location = new System.Drawing.Point(374, 279);
            this.lgn_btn.Name = "lgn_btn";
            this.lgn_btn.Size = new System.Drawing.Size(100, 37);
            this.lgn_btn.TabIndex = 2;
            this.lgn_btn.Text = "Login";
            this.lgn_btn.UseVisualStyleBackColor = true;
            this.lgn_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // lgnPassword_lbl
            // 
            this.lgnPassword_lbl.AutoSize = true;
            this.lgnPassword_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgnPassword_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lgnPassword_lbl.Location = new System.Drawing.Point(236, 199);
            this.lgnPassword_lbl.Name = "lgnPassword_lbl";
            this.lgnPassword_lbl.Size = new System.Drawing.Size(96, 24);
            this.lgnPassword_lbl.TabIndex = 3;
            this.lgnPassword_lbl.Text = "Password";
            this.lgnPassword_lbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // lgnPassword_txt
            // 
            this.lgnPassword_txt.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgnPassword_txt.Location = new System.Drawing.Point(349, 196);
            this.lgnPassword_txt.Name = "lgnPassword_txt";
            this.lgnPassword_txt.Size = new System.Drawing.Size(171, 32);
            this.lgnPassword_txt.TabIndex = 4;
            // 
            // link_lbl
            // 
            this.link_lbl.AutoSize = true;
            this.link_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link_lbl.Location = new System.Drawing.Point(386, 371);
            this.link_lbl.Name = "link_lbl";
            this.link_lbl.Size = new System.Drawing.Size(108, 24);
            this.link_lbl.TabIndex = 5;
            this.link_lbl.TabStop = true;
            this.link_lbl.Text = "Move Next";
            this.link_lbl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.Decode_btn1);
            this.panel1.Controls.Add(this.Encode_btn1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(158, 410);
            this.panel1.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Image_Steganography.Properties.Resources.download__1_;
            this.pictureBox1.Location = new System.Drawing.Point(155, -32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(566, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Decode_btn1
            // 
            this.Decode_btn1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Decode_btn1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Decode_btn1.Location = new System.Drawing.Point(-2, 170);
            this.Decode_btn1.Name = "Decode_btn1";
            this.Decode_btn1.Size = new System.Drawing.Size(153, 56);
            this.Decode_btn1.TabIndex = 10;
            this.Decode_btn1.Text = "Decode";
            this.Decode_btn1.UseVisualStyleBackColor = true;
            // 
            // Encode_btn1
            // 
            this.Encode_btn1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Encode_btn1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Encode_btn1.Location = new System.Drawing.Point(-2, 110);
            this.Encode_btn1.Name = "Encode_btn1";
            this.Encode_btn1.Size = new System.Drawing.Size(149, 53);
            this.Encode_btn1.TabIndex = 8;
            this.Encode_btn1.Text = "Encode";
            this.Encode_btn1.UseVisualStyleBackColor = true;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(721, 409);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.link_lbl);
            this.Controls.Add(this.lgnPassword_txt);
            this.Controls.Add(this.lgnPassword_lbl);
            this.Controls.Add(this.lgn_btn);
            this.Controls.Add(this.lgnName_txt);
            this.Controls.Add(this.lgnName_lbl);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lgnName_lbl;
        private System.Windows.Forms.TextBox lgnName_txt;
        private System.Windows.Forms.Button lgn_btn;
        private System.Windows.Forms.Label lgnPassword_lbl;
        private System.Windows.Forms.TextBox lgnPassword_txt;
        private System.Windows.Forms.LinkLabel link_lbl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Decode_btn1;
        private System.Windows.Forms.Button Encode_btn1;
    }
}