﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Image_Steganography
{
    public partial class SignUp : Form
    {
        public static string SetValueForId = "";
        public SignUp()
        {
            InitializeComponent();
            
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void signup_btn_Click(object sender, EventArgs e)
        {
            List<string> idList = new List<string>();
            string setting = "Data Source=DESKTOP-2OSJ5NQ;Initial Catalog=AoA_database;Integrated Security=True";
            SqlConnection connection = new SqlConnection(setting);
            connection.Open();
            string query = "insert into Table_7(Name,Password)values('" + Name_txt.Text + "','" + Password_txt.Text + "')";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            MessageBox.Show("Sign Up Successfully");
            query = "select Id from Table_7 where Name='" + Name_txt.Text + "'";
            SqlCommand cmd1 = new SqlCommand(query, connection);
            cmd1.Connection = connection;
            SqlDataReader reader = cmd1.ExecuteReader();
            while (reader.Read())
            {
                idList.Add(reader.GetValue(0).ToString());
            }
            Id_txt.Text = displayMembers(idList);
         
        reader.Close();
            cmd1.Dispose();
            connection.Close();
        }
        public string displayMembers(List<String> idList)
        {            return string.Join(", ", idList.ToArray());
        }


        private void login_btn_Click(object sender, EventArgs e)
        {
            SetValueForId = Id_txt.Text;
            Login lg = new Login(SetValueForId);
            lg.Show();
            this.Hide();
                
        }
    }
}
